# Note Studio
 Landig page project with HTML, CSS, JS, and Django
